//
//  ViewController.swift
//  PushNotificationLocalSwift
//
//  Created by MAC OS on 6/21/17.
//  Copyright © 2017 MAC OS. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController, UNUserNotificationCenterDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        initNotificationSetupCheck();
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        
        
    }
    func initNotificationSetupCheck() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) { (success, error) in
            if success {
                print("success")
            } else {
                print("error")
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnclick(_ sender: Any) {
        
        let notification = UNMutableNotificationContent();
        notification.title = "Tops Technologies.!!";
        notification.subtitle = "Training Outsourcing Placement Services.";
        notification.body = "All Training Cources Available.";
    
        
        let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false);
        
        let request = UNNotificationRequest(identifier: "notification", content: notification, trigger: notificationTrigger);
        
         UNUserNotificationCenter
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil);
    }

}

